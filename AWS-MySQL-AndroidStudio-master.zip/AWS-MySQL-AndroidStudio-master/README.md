# AWS-MySQL-AndroidStudio
Linking AWS RDS MySQL DB with Android Studio using Java
